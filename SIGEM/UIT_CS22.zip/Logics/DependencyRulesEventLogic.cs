// v3.8.4.5.b

using System;
using System.Collections.Generic;
using System.Text;

namespace SIGEM.Client.Logics
{
	public enum DependencyRulesEventLogic
	{
		SetValue,
		SetActive
	}
}

