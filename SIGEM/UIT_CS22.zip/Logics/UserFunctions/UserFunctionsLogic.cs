// v3.8.4.5.b
using System;
using System.Collections.Generic;
using System.Text;

using SIGEM.Client.Adaptor;
using SIGEM.Client.Oids;


namespace SIGEM.Client.Logics
{

	public abstract class UserFunctions
	{

	}
}
