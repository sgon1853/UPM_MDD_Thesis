// v3.8.4.5.b
using System;
using SIGEM.Client.Logics;
using SIGEM.Client.Controllers;
using SIGEM.Client.Presentation;
using System.Collections.Generic;

namespace SIGEM.Client.ControllerFactory
{
	/// <summary>
	/// Class that manages the Defined Selection patterns defined in the model.
	/// </summary>
	public static class DefinedSelections
	{
	}
}
