// v3.8.4.5.b
using System;

namespace SIGEM.Client.ControllerFactory
{
	/// <summary>
	/// Class that manages the introduction patterns defined in the model.
	/// </summary>
	public static class IntroductionPatterns
	{
	}
}
