// v3.8.4.5.b
using System;
namespace SIGEM.Client.Controllers
{
	/// <summary>
	/// Stores information related to Refresh Page event.
	/// </summary>
	public class RefreshPageEventArgs: EventArgs
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of 'RefreshPageEventArgs'.
		/// </summary>
		public RefreshPageEventArgs()
		{
		}
		#endregion Constructors
	}
}


