// v3.8.4.5.b
using System;

namespace SIGEM.Client.Controllers
{
	/// <summary>
	/// Stores information related to Previous Page event.
	/// </summary>
	public class PreviousPageEventArgs: EventArgs
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of 'PreviousPageEventArgs'.
		/// </summary>
		public PreviousPageEventArgs()
		{
		}
		#endregion Constructors
	}
}


