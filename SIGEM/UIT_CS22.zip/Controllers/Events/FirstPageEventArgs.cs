// v3.8.4.5.b
using System;

namespace SIGEM.Client.Controllers
{
	/// <summary>
	/// Stores information related to FirstPage event.
	/// </summary>
	public class FirstPageEventArgs: EventArgs
	{
		#region Constructors
		/// <summary>
		/// Initilizes a new instance of 'FirstPageEventArgs'.
		/// </summary>
		public FirstPageEventArgs()
		{
		}
		#endregion Constructors
	}
}


