// v3.8.4.5.b
using System;

namespace SIGEM.Client.Controllers
{
	/// <summary>
	/// TriggerEventArgs class.
	/// </summary>
	public class TriggerEventArgs:EventArgs
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the 'TriggerEventArgs' class.
		/// </summary>
		public TriggerEventArgs()
		{
		}
		#endregion Constructors
	}
}


