// v3.8.4.5.b
using System;

namespace SIGEM.Client.Controllers
{
	/// <summary>
	/// LostFocusEventArgs class.
	/// </summary>
	public class LostFocusEventArgs: EventArgs
	{
		#region Constructors
		/// <summary>
		/// Initializes a new instance of the 'LostFocusEventArgs' class.
		/// </summary>
		public LostFocusEventArgs()
		{
		}
		#endregion Constructors
	}
}


