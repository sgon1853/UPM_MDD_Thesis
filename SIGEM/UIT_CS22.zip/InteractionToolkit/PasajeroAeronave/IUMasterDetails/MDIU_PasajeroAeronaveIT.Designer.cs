

 




// v3.8.4.5.b
namespace SIGEM.Client.InteractionToolkit.PasajeroAeronave.IUMasterDetails
{
	public partial class MDIU_PasajeroAeronaveIT
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.splitMD = new System.Windows.Forms.SplitContainer();

			this.MastercontextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.MastertoolStripHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.MasteroptionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.MastertoolStripExportExcel = new System.Windows.Forms.ToolStripMenuItem();
			this.MastertoolStripExportWord = new System.Windows.Forms.ToolStripMenuItem();
			this.MastertoolStripSeparatorOptions = new System.Windows.Forms.ToolStripSeparator();
			this.MastertoolStripRefresh = new System.Windows.Forms.ToolStripMenuItem();
			this.MastertoolStripPreferences = new System.Windows.Forms.ToolStripMenuItem();
			this.MastertoolStripSavePositions = new System.Windows.Forms.ToolStripMenuItem();
			this.MastertoolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.MastertoolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.pnlOIDSelectorMaster = new System.Windows.Forms.Panel();
			this.lOIDSelectorMaster = new System.Windows.Forms.Label();
			this.maskedTextBoxMasterid_PasajeroAeronave1 = new System.Windows.Forms.MaskedTextBox();
			this.bOIDSelectorMaster = new System.Windows.Forms.Button();
			this.lSIOIDSelectorMaster = new System.Windows.Forms.Label();
			this.pnlActionsMaster = new System.Windows.Forms.Panel();
			this.toolstripActionsMaster = new System.Windows.Forms.ToolStrip();
			this.mnuActionsMaster_0 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripActionsMaster_0 = new System.Windows.Forms.ToolStripButton();
			this.mnuActionsMaster_1 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripActionsMaster_1 = new System.Windows.Forms.ToolStripButton();
			this.mnuActionsMaster_2 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripActionsMaster_2 = new System.Windows.Forms.ToolStripButton();
			this.mnuActionsMaster_3 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripActionsMaster_3 = new System.Windows.Forms.ToolStripButton();
			this.mnuActionsMaster_4 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripActionsMaster_4 = new System.Windows.Forms.ToolStripButton();
			this.mnuPrintMaster = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripPrintMaster = new System.Windows.Forms.ToolStripButton();
			this.pnlNavigationsMaster = new System.Windows.Forms.Panel();
			this.toolstripNavigationsMaster = new System.Windows.Forms.ToolStrip();
			this.mnuNavigationsMaster = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuNavigationsMaster_0 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripNavigationsMaster_0 = new System.Windows.Forms.ToolStripButton();
			this.mnuNavigationsMaster_1 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripNavigationsMaster_1 = new System.Windows.Forms.ToolStripButton();
			this.mnuNavigationsMaster_2 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripNavigationsMaster_2 = new System.Windows.Forms.ToolStripButton();
			this.pnlDisplaySetMaster = new System.Windows.Forms.Panel();
			this.lstViewDisplaySetMaster = new System.Windows.Forms.ListView();
			this.lstViewDisplaySetMasterName = new System.Windows.Forms.ColumnHeader();
			this.lstViewDisplaySetMasterValue = new System.Windows.Forms.ColumnHeader();

			this.Detail0contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.Detail0toolStripHelp = new System.Windows.Forms.ToolStripMenuItem();
			this.Detail0optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.Detail0toolStripExportExcel = new System.Windows.Forms.ToolStripMenuItem();
			this.Detail0toolStripExportWord = new System.Windows.Forms.ToolStripMenuItem();
			this.Detail0toolStripSeparatorOptions = new System.Windows.Forms.ToolStripSeparator();
			this.Detail0toolStripRetrieveAll = new System.Windows.Forms.ToolStripMenuItem();
			this.Detail0toolStripRefresh = new System.Windows.Forms.ToolStripMenuItem();
			this.Detail0toolStripPreferences = new System.Windows.Forms.ToolStripMenuItem();
			this.Detail0toolStripSaveColumnWidth = new System.Windows.Forms.ToolStripMenuItem();
			this.Detail0toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
			this.pnlActionsDetail0 = new System.Windows.Forms.Panel();
			this.toolstripActionsDetail0 = new System.Windows.Forms.ToolStrip();
			this.mnuActionsDetail0_0 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripActionsDetail0_0 = new System.Windows.Forms.ToolStripButton();
			this.mnuActionsDetail0_1 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripActionsDetail0_1 = new System.Windows.Forms.ToolStripButton();
			this.mnuActionsDetail0_2 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripActionsDetail0_2 = new System.Windows.Forms.ToolStripButton();
			this.mnuActionsDetail0_3 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripActionsDetail0_3 = new System.Windows.Forms.ToolStripButton();
			this.mnuPrintDetail0 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripPrintDetail0 = new System.Windows.Forms.ToolStripButton();
			this.Detail0toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
			this.pnlNavigationsDetail0 = new System.Windows.Forms.Panel();
			this.toolstripNavigationsDetail0 = new System.Windows.Forms.ToolStrip();
			this.mnuNavigationsDetail0 = new System.Windows.Forms.ToolStripMenuItem();
			this.mnuNavigationsDetail0_0 = new System.Windows.Forms.ToolStripMenuItem();
			this.toolstripNavigationsDetail0_0 = new System.Windows.Forms.ToolStripButton();
			this.gPopulationDetail0 = new System.Windows.Forms.DataGridView();
			this.statusStripDisplaySetInfoAuxDetail0 = new System.Windows.Forms.StatusStrip();
			this.toolStripStatusLabelBlankDetail0 = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripStatusLabelCountDetail0 = new System.Windows.Forms.ToolStripStatusLabel();
			this.toolStripDropDownButtonSaveDetail0 = new System.Windows.Forms.ToolStripDropDownButton();
            this.panelFormMDButtons = new System.Windows.Forms.Panel();
            this.bCancel = new System.Windows.Forms.Button();
			this.splitMD.Panel1.SuspendLayout();
			this.splitMD.Panel2.SuspendLayout();
			this.splitMD.SuspendLayout();
			this.MastercontextMenuStrip.SuspendLayout();
			this.pnlOIDSelectorMaster.SuspendLayout();
			this.pnlActionsMaster.SuspendLayout();
			this.toolstripActionsMaster.SuspendLayout();
			this.pnlNavigationsMaster.SuspendLayout();
			this.toolstripNavigationsMaster.SuspendLayout();
            this.pnlDisplaySetMaster.SuspendLayout();
			this.Detail0contextMenuStrip.SuspendLayout();
			this.pnlActionsDetail0.SuspendLayout();
			this.toolstripActionsDetail0.SuspendLayout();
			this.pnlNavigationsDetail0.SuspendLayout();
			this.toolstripNavigationsDetail0.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.gPopulationDetail0)).BeginInit();
			this.statusStripDisplaySetInfoAuxDetail0.SuspendLayout();
            this.panelFormMDButtons.SuspendLayout();
            this.SuspendLayout();
			//
			// splitMD
			//
			this.splitMD.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitMD.Location = new System.Drawing.Point(0, 0);
			this.splitMD.Name = "splitMD";
			this.splitMD.Orientation = System.Windows.Forms.Orientation.Horizontal;
			//
			// splitMD.Panel1
			//
			this.splitMD.Panel1.AutoScroll = true;
			this.splitMD.Panel1.Controls.Add(this.pnlDisplaySetMaster);
			this.splitMD.Panel1.Controls.Add(this.pnlActionsMaster);
			this.splitMD.Panel1.Controls.Add(this.pnlNavigationsMaster);
			this.splitMD.Panel1.Controls.Add(this.pnlOIDSelectorMaster);
			//
			// splitMD.Panel2
			//
			this.splitMD.Panel2.Controls.Add(this.gPopulationDetail0);
			this.splitMD.Panel2.Controls.Add(this.statusStripDisplaySetInfoAuxDetail0);
			this.splitMD.Panel2.Controls.Add(this.pnlActionsDetail0);
			this.splitMD.Panel2.Controls.Add(this.pnlNavigationsDetail0);
			this.splitMD.Size = new System.Drawing.Size(550, 500);
			this.splitMD.SplitterDistance = 202;
			this.splitMD.TabIndex = 1;
			//
			// MastercontextMenuStrip
			//
			this.MastercontextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
				this.MastertoolStripHelp,
				this.MasteroptionsToolStripMenuItem,
				this.MastertoolStripSeparator1,
				this.mnuActionsMaster_0,
				this.mnuActionsMaster_1,
				this.mnuActionsMaster_2,
				this.mnuActionsMaster_3,
				this.mnuActionsMaster_4,
				this.mnuPrintMaster,
				this.MastertoolStripSeparator2,
				this.mnuNavigationsMaster});
			this.MastercontextMenuStrip.Name = "MastercontextMenuStrip";
			this.MastercontextMenuStrip.Size = new System.Drawing.Size(131, 148);
			//
			// MastertoolStripHelp
			//
			this.MastertoolStripHelp.Image = global::SIGEM.Client.Properties.Resources.help;
			this.MastertoolStripHelp.Name = "MastertoolStripHelp";
			this.MastertoolStripHelp.Size = new System.Drawing.Size(130, 22);
			this.MastertoolStripHelp.Text = "Help";
			//
			// MasteroptionsToolStripMenuItem
			//
			this.MasteroptionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
				this.MastertoolStripExportExcel,
				this.MastertoolStripExportWord,
				this.MastertoolStripSeparatorOptions,
				this.MastertoolStripRefresh,
				this.MastertoolStripPreferences,
				this.MastertoolStripSavePositions});
			this.MasteroptionsToolStripMenuItem.Name = "MasteroptionsToolStripMenuItem";
			this.MasteroptionsToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
			this.MasteroptionsToolStripMenuItem.Text = "Options";
			//
			// MastertoolStripExportExcel
			//
			this.MastertoolStripExportExcel.Image = global::SIGEM.Client.Properties.Resources.exportToExcel;
			this.MastertoolStripExportExcel.Name = "MastertoolStripExportExcel";
			this.MastertoolStripExportExcel.Size = new System.Drawing.Size(67, 22);
			this.MastertoolStripExportExcel.Text = "Export To Excel";
			//
			// MastertoolStripExportWord
			//
			this.MastertoolStripExportWord.Image = global::SIGEM.Client.Properties.Resources.exportToWord;
			this.MastertoolStripExportWord.Name = "MastertoolStripExportWord";
			this.MastertoolStripExportWord.Size = new System.Drawing.Size(67, 22);
			this.MastertoolStripExportWord.Text = "Export To Word";
			this.MastertoolStripExportWord.Visible = false;
			//
			// MastertoolStripSeparatorOptions
			//
			this.MastertoolStripSeparatorOptions.Name = "MastertoolStripSeparatorOptions";
			this.MastertoolStripSeparatorOptions.Size = new System.Drawing.Size(64, 6);
			//
			// MastertoolStripRefresh
			//
			this.MastertoolStripRefresh.Image = global::SIGEM.Client.Properties.Resources.refresh;
			this.MastertoolStripRefresh.Name = "MastertoolStripRefresh";
			this.MastertoolStripRefresh.Size = new System.Drawing.Size(67, 22);
			this.MastertoolStripRefresh.Text = "Refresh";
			//
			// MastertoolStripPreferences
			//
			this.MastertoolStripPreferences.Image = global::SIGEM.Client.Properties.Resources.preferences;
			this.MastertoolStripPreferences.Name = "MastertoolStripPreferences";
			this.MastertoolStripPreferences.Size = new System.Drawing.Size(67, 22);
			this.MastertoolStripPreferences.Text = "Preferences";
			//
			// MastertoolStripSavePositions
			//
			this.MastertoolStripSavePositions.Image = global::SIGEM.Client.Properties.Resources.savePosition;
			this.MastertoolStripSavePositions.Name = "MastertoolStripSavePositions";
			this.MastertoolStripSavePositions.Size = new System.Drawing.Size(67, 22);
			this.MastertoolStripSavePositions.Text = "Save position";
			//
			// MastertoolStripSeparator1
			//
			this.MastertoolStripSeparator1.Name = "MastertoolStripSeparator1";
			this.MastertoolStripSeparator1.Size = new System.Drawing.Size(127, 6);
			//
			// mnuActionsMaster_0
			//
			this.mnuActionsMaster_0.Image = global::SIGEM.Client.Properties.Resources.PasajeroAeronave_SIU_SIU_create_instance;
			this.mnuActionsMaster_0.Name = "mnuActionsMaster_0";
			this.mnuActionsMaster_0.Size = new System.Drawing.Size(130, 22);
			//
			// mnuActionsMaster_1
			//
			this.mnuActionsMaster_1.Image = global::SIGEM.Client.Properties.Resources.PasajeroAeronave_SIU_SIU_delete_instance;
			this.mnuActionsMaster_1.Name = "mnuActionsMaster_1";
			this.mnuActionsMaster_1.Size = new System.Drawing.Size(130, 22);
			//
			// mnuActionsMaster_2
			//
			this.mnuActionsMaster_2.Image = global::SIGEM.Client.Properties.Resources.PasajeroAeronave_SIU_SIU_edit_instance;
			this.mnuActionsMaster_2.Name = "mnuActionsMaster_2";
			this.mnuActionsMaster_2.Size = new System.Drawing.Size(130, 22);
			//
			// mnuActionsMaster_3
			//
			this.mnuActionsMaster_3.Image = global::SIGEM.Client.Properties.Resources.PasajeroAeronave_IIU_IIU_PasajeroAeronave;
			this.mnuActionsMaster_3.Name = "mnuActionsMaster_3";
			this.mnuActionsMaster_3.Size = new System.Drawing.Size(130, 22);
			//
			// mnuActionsMaster_4
			//
			this.mnuActionsMaster_4.Image = global::SIGEM.Client.Properties.Resources.PasajeroAeronave_MDIU_MDIU_PasajeroAeronave;
			this.mnuActionsMaster_4.Name = "mnuActionsMaster_4";
			this.mnuActionsMaster_4.Size = new System.Drawing.Size(130, 22);
			//
			// mnuPrintMaster
			//
			this.mnuPrintMaster.Image = global::SIGEM.Client.Properties.Resources.print;
			this.mnuPrintMaster.Name = "mnuPrintMaster";
			this.mnuPrintMaster.Size = new System.Drawing.Size(130, 22);
			//
			// MastertoolStripSeparator2
			//
			this.MastertoolStripSeparator2.Name = "MastertoolStripSeparator2";
			this.MastertoolStripSeparator2.Size = new System.Drawing.Size(127, 6);
			//
			// mnuNavigationsMaster
			//
			this.mnuNavigationsMaster.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
				this.mnuNavigationsMaster_0,
				this.mnuNavigationsMaster_1,
				this.mnuNavigationsMaster_2});
			this.mnuNavigationsMaster.Name = "mnuNavigationsMaster";
			this.mnuNavigationsMaster.Size = new System.Drawing.Size(130, 22);
			this.mnuNavigationsMaster.Text = "Navigations";
			//
			// mnuNavigationsMaster_0
			//
			this.mnuNavigationsMaster_0.Name = "mnuNavigationsMaster_0";
			this.mnuNavigationsMaster_0.Size = new System.Drawing.Size(67, 22);
			//
			// mnuNavigationsMaster_1
			//
			this.mnuNavigationsMaster_1.Name = "mnuNavigationsMaster_1";
			this.mnuNavigationsMaster_1.Size = new System.Drawing.Size(67, 22);
			//
			// mnuNavigationsMaster_2
			//
			this.mnuNavigationsMaster_2.Name = "mnuNavigationsMaster_2";
			this.mnuNavigationsMaster_2.Size = new System.Drawing.Size(67, 22);
			//
			// pnlOIDSelectorMaster
			//
			this.pnlOIDSelectorMaster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlOIDSelectorMaster.Controls.Add(this.lOIDSelectorMaster);
			this.pnlOIDSelectorMaster.Controls.Add(this.maskedTextBoxMasterid_PasajeroAeronave1);
			this.pnlOIDSelectorMaster.Controls.Add(this.bOIDSelectorMaster);
			this.pnlOIDSelectorMaster.Controls.Add(this.lSIOIDSelectorMaster);
			this.pnlOIDSelectorMaster.Dock = System.Windows.Forms.DockStyle.Top;
			this.pnlOIDSelectorMaster.Location = new System.Drawing.Point(0, 0);
			this.pnlOIDSelectorMaster.Name = "pnlOIDSelectorMaster";
			this.pnlOIDSelectorMaster.Size = new System.Drawing.Size(620, 32);
			this.pnlOIDSelectorMaster.TabIndex = 0;
			//
			// lOIDSelectorMaster
			//
			this.lOIDSelectorMaster.AutoEllipsis = true;
			this.lOIDSelectorMaster.Location = new System.Drawing.Point(10, 9);
			this.lOIDSelectorMaster.Name = "lOIDSelectorMaster";
			this.lOIDSelectorMaster.Size = new System.Drawing.Size(90, 16);
			this.lOIDSelectorMaster.TabIndex = 0;
			this.lOIDSelectorMaster.Text = "PasajeroAeronave";
			//
			// maskedTextBoxMasterid_PasajeroAeronave1
			//
			this.maskedTextBoxMasterid_PasajeroAeronave1.Location = new System.Drawing.Point(102, 6);
			this.maskedTextBoxMasterid_PasajeroAeronave1.Margin = new System.Windows.Forms.Padding(2);
			this.maskedTextBoxMasterid_PasajeroAeronave1.Name = "maskedTextBoxMasterid_PasajeroAeronave1";
			this.maskedTextBoxMasterid_PasajeroAeronave1.Size = new System.Drawing.Size(72, 20);
			this.maskedTextBoxMasterid_PasajeroAeronave1.TabIndex = 0;
			//
			// bOIDSelectorMaster
			//
			this.bOIDSelectorMaster.Image = global::SIGEM.Client.Properties.Resources.search;
			this.bOIDSelectorMaster.Location = new System.Drawing.Point(175, 5);
			this.bOIDSelectorMaster.Margin = new System.Windows.Forms.Padding(2);
			this.bOIDSelectorMaster.Name = "bOIDSelectorMaster";
			this.bOIDSelectorMaster.Size = new System.Drawing.Size(22, 22);
			this.bOIDSelectorMaster.TabIndex = 1;
			this.bOIDSelectorMaster.UseVisualStyleBackColor = true;
			//
			// lSIOIDSelectorMaster
			//
			this.lSIOIDSelectorMaster.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.lSIOIDSelectorMaster.AutoEllipsis = true;
			this.lSIOIDSelectorMaster.Location = new System.Drawing.Point(199, 9);
			this.lSIOIDSelectorMaster.Name = "lSIOIDSelectorMaster";
			this.lSIOIDSelectorMaster.Size = new System.Drawing.Size(330, 16);
			this.lSIOIDSelectorMaster.TabIndex = 0;
			//
			// pnlActionsMaster
			//
			this.pnlActionsMaster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlActionsMaster.Controls.Add(this.toolstripActionsMaster);
			this.pnlActionsMaster.Dock = System.Windows.Forms.DockStyle.Right;
			this.pnlActionsMaster.Location = new System.Drawing.Point(620, 32);
			this.pnlActionsMaster.Name = "pnlActionsMaster";
			this.pnlActionsMaster.Size = new System.Drawing.Size(30, 140);
			this.pnlActionsMaster.TabIndex = 2;
			//
			// toolstripActionsMaster
			//
			this.toolstripActionsMaster.AutoSize = false;
			this.toolstripActionsMaster.BackColor = System.Drawing.SystemColors.ControlLight;
			this.toolstripActionsMaster.Dock = System.Windows.Forms.DockStyle.Fill;
			this.toolstripActionsMaster.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolstripActionsMaster.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
				this.toolstripActionsMaster_0,
				this.toolstripActionsMaster_1,
				this.toolstripActionsMaster_2,
				this.toolstripActionsMaster_3,
				this.toolstripActionsMaster_4,
				this.toolStripPrintMaster});
			this.toolstripActionsMaster.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
			this.toolstripActionsMaster.Location = new System.Drawing.Point(0, 0);
			this.toolstripActionsMaster.Name = "toolstripActionsMaster";
			this.toolstripActionsMaster.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
			this.toolstripActionsMaster.Size = new System.Drawing.Size(28, 138);
			this.toolstripActionsMaster.TabIndex = 2;
			//
			// toolstripActionsMaster_0
			//
			this.toolstripActionsMaster_0.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolstripActionsMaster_0.Image = global::SIGEM.Client.Properties.Resources.PasajeroAeronave_SIU_SIU_create_instance;
			this.toolstripActionsMaster_0.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripActionsMaster_0.Name = "toolstripActionsMaster_0";
			this.toolstripActionsMaster_0.Size = new System.Drawing.Size(26, 20);
			this.toolstripActionsMaster_0.Text = "New";
			//
			// toolstripActionsMaster_1
			//
			this.toolstripActionsMaster_1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolstripActionsMaster_1.Image = global::SIGEM.Client.Properties.Resources.PasajeroAeronave_SIU_SIU_delete_instance;
			this.toolstripActionsMaster_1.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripActionsMaster_1.Name = "toolstripActionsMaster_1";
			this.toolstripActionsMaster_1.Size = new System.Drawing.Size(26, 20);
			this.toolstripActionsMaster_1.Text = "Destroy";
			//
			// toolstripActionsMaster_2
			//
			this.toolstripActionsMaster_2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolstripActionsMaster_2.Image = global::SIGEM.Client.Properties.Resources.PasajeroAeronave_SIU_SIU_edit_instance;
			this.toolstripActionsMaster_2.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripActionsMaster_2.Name = "toolstripActionsMaster_2";
			this.toolstripActionsMaster_2.Size = new System.Drawing.Size(26, 20);
			this.toolstripActionsMaster_2.Text = "Edit";
			//
			// toolstripActionsMaster_3
			//
			this.toolstripActionsMaster_3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolstripActionsMaster_3.Image = global::SIGEM.Client.Properties.Resources.PasajeroAeronave_IIU_IIU_PasajeroAeronave;
			this.toolstripActionsMaster_3.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripActionsMaster_3.Name = "toolstripActionsMaster_3";
			this.toolstripActionsMaster_3.Size = new System.Drawing.Size(26, 20);
			this.toolstripActionsMaster_3.Text = "PasajeroAeronave";
			//
			// toolstripActionsMaster_4
			//
			this.toolstripActionsMaster_4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolstripActionsMaster_4.Image = global::SIGEM.Client.Properties.Resources.PasajeroAeronave_MDIU_MDIU_PasajeroAeronave;
			this.toolstripActionsMaster_4.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripActionsMaster_4.Name = "toolstripActionsMaster_4";
			this.toolstripActionsMaster_4.Size = new System.Drawing.Size(26, 20);
			this.toolstripActionsMaster_4.Text = "PasajeroAeronave";
			//
			// toolStripPrintMaster
			//
			this.toolStripPrintMaster.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripPrintMaster.Image = global::SIGEM.Client.Properties.Resources.print;
			this.toolStripPrintMaster.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripPrintMaster.Name = "toolStripPrintMaster";
			this.toolStripPrintMaster.Size = new System.Drawing.Size(26, 20);
			this.toolStripPrintMaster.Text = "Print";
			//
			// pnlNavigationsMaster
			//
			this.pnlNavigationsMaster.BackColor = System.Drawing.SystemColors.ControlLight;
			this.pnlNavigationsMaster.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlNavigationsMaster.Controls.Add(this.toolstripNavigationsMaster);
			this.pnlNavigationsMaster.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.pnlNavigationsMaster.Location = new System.Drawing.Point(0, 172);
			this.pnlNavigationsMaster.Name = "pnlNavigationsMaster";
			this.pnlNavigationsMaster.Size = new System.Drawing.Size(650, 30);
			this.pnlNavigationsMaster.TabIndex = 3;
			//
			// toolstripNavigationsMaster
			//
			this.toolstripNavigationsMaster.Dock = System.Windows.Forms.DockStyle.Fill;
			this.toolstripNavigationsMaster.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolstripNavigationsMaster.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
				this.toolstripNavigationsMaster_0,
				this.toolstripNavigationsMaster_1,
				this.toolstripNavigationsMaster_2});
			this.toolstripNavigationsMaster.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
			this.toolstripNavigationsMaster.Location = new System.Drawing.Point(0, 0);
			this.toolstripNavigationsMaster.Name = "toolstripNavigationsMaster";
			this.toolstripNavigationsMaster.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
			this.toolstripNavigationsMaster.Size = new System.Drawing.Size(648, 28);
			this.toolstripNavigationsMaster.TabIndex = 3;
			//
			// toolstripNavigationsMaster_0
			//
			this.toolstripNavigationsMaster_0.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripNavigationsMaster_0.Name = "toolstripNavigationsMaster_0";
			this.toolstripNavigationsMaster_0.Size = new System.Drawing.Size(48, 27);
			this.toolstripNavigationsMaster_0.Text = "RevisionPasajero";
			this.toolstripNavigationsMaster_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			//
			// toolstripNavigationsMaster_1
			//
			this.toolstripNavigationsMaster_1.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripNavigationsMaster_1.Name = "toolstripNavigationsMaster_1";
			this.toolstripNavigationsMaster_1.Size = new System.Drawing.Size(48, 27);
			this.toolstripNavigationsMaster_1.Text = "Aeronave";
			this.toolstripNavigationsMaster_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			//
			// toolstripNavigationsMaster_2
			//
			this.toolstripNavigationsMaster_2.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripNavigationsMaster_2.Name = "toolstripNavigationsMaster_2";
			this.toolstripNavigationsMaster_2.Size = new System.Drawing.Size(48, 27);
			this.toolstripNavigationsMaster_2.Text = "Pasajero";
			this.toolstripNavigationsMaster_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			//
			// pnlDisplaySetMaster
			//
			this.pnlDisplaySetMaster.AutoScroll = true;
			this.pnlDisplaySetMaster.Controls.Add(this.lstViewDisplaySetMaster);
			this.pnlDisplaySetMaster.Dock = System.Windows.Forms.DockStyle.Fill;
			this.pnlDisplaySetMaster.Location = new System.Drawing.Point(0, 32);
			this.pnlDisplaySetMaster.Name = "pnlDisplaySetMaster";
			this.pnlDisplaySetMaster.Size = new System.Drawing.Size(620, 140);
			this.pnlDisplaySetMaster.TabIndex = 1;
			//
			// lstViewDisplaySetMaster
			//
			this.lstViewDisplaySetMaster.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
				this.lstViewDisplaySetMasterName,
				this.lstViewDisplaySetMasterValue});
			this.lstViewDisplaySetMaster.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lstViewDisplaySetMaster.Location = new System.Drawing.Point(0, 0);
			this.lstViewDisplaySetMaster.Name = "lstViewDisplaySetMaster";
			this.lstViewDisplaySetMaster.Size = new System.Drawing.Size(620, 140);
			this.lstViewDisplaySetMaster.TabIndex = 0;
			this.lstViewDisplaySetMaster.UseCompatibleStateImageBehavior = false;
			this.lstViewDisplaySetMaster.View = System.Windows.Forms.View.Details;
			//
			// lstViewDisplaySetMasterName
			//
			this.lstViewDisplaySetMasterName.Text = "Name";
			this.lstViewDisplaySetMasterName.Width = 200;
			//
			// lstViewDisplaySetMasterValue
			//
			this.lstViewDisplaySetMasterValue.Text = "Value";
			this.lstViewDisplaySetMasterValue.Width = 295;
			//
			// Detail0contextMenuStrip
			//
			this.Detail0contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
				this.Detail0toolStripHelp,
				this.Detail0optionsToolStripMenuItem,
				this.Detail0toolStripSeparator1,
				this.mnuActionsDetail0_0,
				this.mnuActionsDetail0_1,
				this.mnuActionsDetail0_2,
				this.mnuActionsDetail0_3,
				this.mnuPrintDetail0,
				this.Detail0toolStripSeparator2,
				this.mnuNavigationsDetail0});
			this.Detail0contextMenuStrip.Name = "Detail0contextMenuStrip";
			this.Detail0contextMenuStrip.Size = new System.Drawing.Size(131, 148);
			//
			// Detail0toolStripHelp
			//
			this.Detail0toolStripHelp.Image = global::SIGEM.Client.Properties.Resources.help;
			this.Detail0toolStripHelp.Name = "Detail0toolStripHelp";
			this.Detail0toolStripHelp.Size = new System.Drawing.Size(130, 22);
			this.Detail0toolStripHelp.Text = "Help";
			//
			// Detail0optionsToolStripMenuItem
			//
			this.Detail0optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
				this.Detail0toolStripExportExcel,
				this.Detail0toolStripExportWord,
				this.Detail0toolStripSeparatorOptions,
				this.Detail0toolStripRetrieveAll,
				this.Detail0toolStripRefresh,
				this.Detail0toolStripPreferences,
				this.Detail0toolStripSaveColumnWidth
				});
			this.Detail0optionsToolStripMenuItem.Name = "Detail0optionsToolStripMenuItem";
			this.Detail0optionsToolStripMenuItem.Size = new System.Drawing.Size(130, 22);
			this.Detail0optionsToolStripMenuItem.Text = "Options";
			//
			// Detail0toolStripExportExcel
			//
			this.Detail0toolStripExportExcel.Image = global::SIGEM.Client.Properties.Resources.exportToExcel;
			this.Detail0toolStripExportExcel.Name = "Detail0toolStripExportExcel";
			this.Detail0toolStripExportExcel.Size = new System.Drawing.Size(174, 22);
			this.Detail0toolStripExportExcel.Text = "Export To Excel}";
			//
			// Detail0toolStripExportWord
			//
			this.Detail0toolStripExportWord.Image = global::SIGEM.Client.Properties.Resources.exportToWord;
			this.Detail0toolStripExportWord.Name = "Detail0toolStripExportWord";
			this.Detail0toolStripExportWord.Size = new System.Drawing.Size(174, 22);
			this.Detail0toolStripExportWord.Text = "Export To Word";
			this.Detail0toolStripExportWord.Visible = false;
			//
			// Detail0toolStripSeparatorOptions
			//
			this.Detail0toolStripSeparatorOptions.Name = "Detail0toolStripSeparatorOptions";
			this.Detail0toolStripSeparatorOptions.Size = new System.Drawing.Size(171, 6);
			//
			// Detail0toolStripRetrieveAll
			//
			this.Detail0toolStripRetrieveAll.Name = "Detail0toolStripRetrieveAll";
			this.Detail0toolStripRetrieveAll.Size = new System.Drawing.Size(174, 22);
			this.Detail0toolStripRetrieveAll.Text = "Retrieve All";
			//
			// Detail0toolStripRefresh
			//
			this.Detail0toolStripRefresh.Image = global::SIGEM.Client.Properties.Resources.refresh;
			this.Detail0toolStripRefresh.Name = "Detail0toolStripRefresh";
			this.Detail0toolStripRefresh.Size = new System.Drawing.Size(174, 22);
			this.Detail0toolStripRefresh.Text = "Refresh";
			//
			// Detail0toolStripPreferences
			//
			this.Detail0toolStripPreferences.Image = global::SIGEM.Client.Properties.Resources.preferences;
			this.Detail0toolStripPreferences.Name = "Detail0toolStripPreferences";
			this.Detail0toolStripPreferences.Size = new System.Drawing.Size(174, 22);
			this.Detail0toolStripPreferences.Text = "Preferences";
			//
			// Detail0toolStripSaveColumnWidth
			//
			this.Detail0toolStripSaveColumnWidth.Image = global::SIGEM.Client.Properties.Resources.saveWidth;
			this.Detail0toolStripSaveColumnWidth.Name = "Detail0toolStripSaveColumnWidth";
			this.Detail0toolStripSaveColumnWidth.Size = new System.Drawing.Size(174, 22);
			this.Detail0toolStripSaveColumnWidth.Text = "Save column width";
			//
			// Detail0toolStripSeparator1
			//
			this.Detail0toolStripSeparator1.Name = "Detail0toolStripSeparator1";
			this.Detail0toolStripSeparator1.Size = new System.Drawing.Size(127, 6);
			//
			// mnuActionsDetail0_0
			//
			this.mnuActionsDetail0_0.Image = global::SIGEM.Client.Properties.Resources.Pasajero_SIU_SIU_create_instance;
			this.mnuActionsDetail0_0.Name = "mnuActionsDetail0_0";
			this.mnuActionsDetail0_0.Size = new System.Drawing.Size(130, 22);
			//
			// mnuActionsDetail0_1
			//
			this.mnuActionsDetail0_1.Image = global::SIGEM.Client.Properties.Resources.Pasajero_SIU_SIU_delete_instance;
			this.mnuActionsDetail0_1.Name = "mnuActionsDetail0_1";
			this.mnuActionsDetail0_1.Size = new System.Drawing.Size(130, 22);
			//
			// mnuActionsDetail0_2
			//
			this.mnuActionsDetail0_2.Image = global::SIGEM.Client.Properties.Resources.Pasajero_SIU_SIU_edit_instance;
			this.mnuActionsDetail0_2.Name = "mnuActionsDetail0_2";
			this.mnuActionsDetail0_2.Size = new System.Drawing.Size(130, 22);
			//
			// mnuActionsDetail0_3
			//
			this.mnuActionsDetail0_3.Image = global::SIGEM.Client.Properties.Resources.Pasajero_IIU__Auto_;
			this.mnuActionsDetail0_3.Name = "mnuActionsDetail0_3";
			this.mnuActionsDetail0_3.Size = new System.Drawing.Size(130, 22);
			//
			// mnuPrintDetail0
			//
			this.mnuPrintDetail0.Image = global::SIGEM.Client.Properties.Resources.print;
			this.mnuPrintDetail0.Name = "mnuPrintDetail0";
			this.mnuPrintDetail0.Size = new System.Drawing.Size(130, 22);
			//
			// Detail0toolStripSeparator2
			//
			this.Detail0toolStripSeparator2.Name = "Detail0toolStripSeparator2";
			this.Detail0toolStripSeparator2.Size = new System.Drawing.Size(127, 6);
			//
			// mnuNavigationsDetail0
			//
			this.mnuNavigationsDetail0.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
				this.mnuNavigationsDetail0_0});
			this.mnuNavigationsDetail0.Name = "mnuNavigationsDetail0";
			this.mnuNavigationsDetail0.Size = new System.Drawing.Size(130, 22);
			this.mnuNavigationsDetail0.Text = "Navigations";
			//
			// mnuNavigationsDetail0_0
			//
			this.mnuNavigationsDetail0_0.Name = "mnuNavigationsDetail0_0";
			this.mnuNavigationsDetail0_0.Size = new System.Drawing.Size(67, 22);
			//
			// pnlActionsDetail0
			//
			this.pnlActionsDetail0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlActionsDetail0.Controls.Add(this.toolstripActionsDetail0);
			this.pnlActionsDetail0.Dock = System.Windows.Forms.DockStyle.Right;
			this.pnlActionsDetail0.Location = new System.Drawing.Point(520, 0);
			this.pnlActionsDetail0.Name = "pnlActionsDetail0";
			this.pnlActionsDetail0.Size = new System.Drawing.Size(30, 267);
			this.pnlActionsDetail0.TabIndex = 0;
			//
			// toolstripActionsDetail0
			//
			this.toolstripActionsDetail0.AutoSize = false;
			this.toolstripActionsDetail0.BackColor = System.Drawing.SystemColors.ControlLight;
			this.toolstripActionsDetail0.Dock = System.Windows.Forms.DockStyle.Fill;
			this.toolstripActionsDetail0.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolstripActionsDetail0.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
				this.toolstripActionsDetail0_0,
				this.toolstripActionsDetail0_1,
				this.toolstripActionsDetail0_2,
				this.toolstripActionsDetail0_3,
				this.toolStripPrintDetail0});
			this.toolstripActionsDetail0.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
			this.toolstripActionsDetail0.Location = new System.Drawing.Point(0, 0);
			this.toolstripActionsDetail0.Name = "toolstripActionsDetail0";
			this.toolstripActionsDetail0.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
			this.toolstripActionsDetail0.Size = new System.Drawing.Size(28, 265);
			this.toolstripActionsDetail0.TabIndex = 0;
			//
			// toolstripActionsDetail0_0
			//
			this.toolstripActionsDetail0_0.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolstripActionsDetail0_0.Image = global::SIGEM.Client.Properties.Resources.Pasajero_SIU_SIU_create_instance;
			this.toolstripActionsDetail0_0.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripActionsDetail0_0.Name = "toolstripActionsDetail0_0";
			this.toolstripActionsDetail0_0.Size = new System.Drawing.Size(26, 20);
			this.toolstripActionsDetail0_0.Text = "New";
			//
			// toolstripActionsDetail0_1
			//
			this.toolstripActionsDetail0_1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolstripActionsDetail0_1.Image = global::SIGEM.Client.Properties.Resources.Pasajero_SIU_SIU_delete_instance;
			this.toolstripActionsDetail0_1.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripActionsDetail0_1.Name = "toolstripActionsDetail0_1";
			this.toolstripActionsDetail0_1.Size = new System.Drawing.Size(26, 20);
			this.toolstripActionsDetail0_1.Text = "Destroy";
			//
			// toolstripActionsDetail0_2
			//
			this.toolstripActionsDetail0_2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolstripActionsDetail0_2.Image = global::SIGEM.Client.Properties.Resources.Pasajero_SIU_SIU_edit_instance;
			this.toolstripActionsDetail0_2.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripActionsDetail0_2.Name = "toolstripActionsDetail0_2";
			this.toolstripActionsDetail0_2.Size = new System.Drawing.Size(26, 20);
			this.toolstripActionsDetail0_2.Text = "Edit";
			//
			// toolstripActionsDetail0_3
			//
			this.toolstripActionsDetail0_3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolstripActionsDetail0_3.Image = global::SIGEM.Client.Properties.Resources.Pasajero_IIU__Auto_;
			this.toolstripActionsDetail0_3.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripActionsDetail0_3.Name = "toolstripActionsDetail0_3";
			this.toolstripActionsDetail0_3.Size = new System.Drawing.Size(26, 20);
			this.toolstripActionsDetail0_3.Text = "Pasajero";
			//
			// toolStripPrintDetail0
			//
			this.toolStripPrintDetail0.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
			this.toolStripPrintDetail0.Image = global::SIGEM.Client.Properties.Resources.print;
			this.toolStripPrintDetail0.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripPrintDetail0.Name = "toolStripPrintDetail0";
			this.toolStripPrintDetail0.Size = new System.Drawing.Size(26, 20);
			this.toolStripPrintDetail0.Text = "Print";
			//
			// pnlNavigationsDetail0
			//
			this.pnlNavigationsDetail0.BackColor = System.Drawing.SystemColors.ControlLight;
			this.pnlNavigationsDetail0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlNavigationsDetail0.Controls.Add(this.toolstripNavigationsDetail0);
			this.pnlNavigationsDetail0.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.pnlNavigationsDetail0.Location = new System.Drawing.Point(267, 300);
			this.pnlNavigationsDetail0.Name = "pnlNavigationsDetail0";
			this.pnlNavigationsDetail0.Size = new System.Drawing.Size(550, 30);
			this.pnlNavigationsDetail0.TabIndex = 0;
			//
			// toolstripNavigationsDetail0
			//
			this.toolstripNavigationsDetail0.Dock = System.Windows.Forms.DockStyle.Fill;
			this.toolstripNavigationsDetail0.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.toolstripNavigationsDetail0.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
				this.toolstripNavigationsDetail0_0});
			this.toolstripNavigationsDetail0.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
			this.toolstripNavigationsDetail0.Location = new System.Drawing.Point(0, 0);
			this.toolstripNavigationsDetail0.Name = "toolstripNavigationsDetail0";
			this.toolstripNavigationsDetail0.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
			this.toolstripNavigationsDetail0.Size = new System.Drawing.Size(548, 28);
			this.toolstripNavigationsDetail0.TabIndex = 0;
			//
			// toolstripNavigationsDetail0_0
			//
			this.toolstripNavigationsDetail0_0.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolstripNavigationsDetail0_0.Name = "toolstripNavigationsDetail0_0";
			this.toolstripNavigationsDetail0_0.Size = new System.Drawing.Size(48, 27);
			this.toolstripNavigationsDetail0_0.Text = "PasajeroAeronave";
			this.toolstripNavigationsDetail0_0.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			//
			// gPopulationDetail0
			//
			this.gPopulationDetail0.AllowUserToAddRows = false;
			this.gPopulationDetail0.AllowUserToDeleteRows = false;
			this.gPopulationDetail0.AlternatingRowsDefaultCellStyle.BackColor = System.Drawing.Color.AliceBlue;
			this.gPopulationDetail0.AutoGenerateColumns= false;
			this.gPopulationDetail0.Dock = System.Windows.Forms.DockStyle.Fill;
			this.gPopulationDetail0.Location = new System.Drawing.Point(0, 0);
			this.gPopulationDetail0.Name = "gPopulationDetail0";
			this.gPopulationDetail0.ReadOnly = true;
			this.gPopulationDetail0.RowHeadersVisible = false;
			this.gPopulationDetail0.RowTemplate.Height = 18;
			this.gPopulationDetail0.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.gPopulationDetail0.ShowCellErrors = false;
			this.gPopulationDetail0.ShowCellToolTips = false;
			this.gPopulationDetail0.ShowEditingIcon = false;
			this.gPopulationDetail0.ShowRowErrors = false;
			this.gPopulationDetail0.Size = new System.Drawing.Size(520, 245);
			this.gPopulationDetail0.TabIndex = 0;
			//
			// statusStripDisplaySetInfoAuxDetail0
			//
			this.statusStripDisplaySetInfoAuxDetail0.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
			this.toolStripStatusLabelBlankDetail0,
			this.toolStripStatusLabelCountDetail0,
			this.toolStripDropDownButtonSaveDetail0});
			this.statusStripDisplaySetInfoAuxDetail0.Location = new System.Drawing.Point(0, 245);
			this.statusStripDisplaySetInfoAuxDetail0.Name = "statusStripDisplaySetInfoAuxDetail0";
			this.statusStripDisplaySetInfoAuxDetail0.Size = new System.Drawing.Size(520, 22);
			this.statusStripDisplaySetInfoAuxDetail0.TabIndex = 3;
			//
			// toolStripStatusLabelBlankDetail0
			//
			this.toolStripStatusLabelBlankDetail0.Name = "toolStripStatusLabelBlankDetail0";
			this.toolStripStatusLabelBlankDetail0.Size = new System.Drawing.Size(505, 17);
			this.toolStripStatusLabelBlankDetail0.Spring = true;
			this.toolStripStatusLabelBlankDetail0.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			//
			// toolStripStatusLabelCountDetail0
			//
			this.toolStripStatusLabelCountDetail0.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
			this.toolStripStatusLabelCountDetail0.Name = "toolStripStatusLabelCountDetail0";
			this.toolStripStatusLabelCountDetail0.Size = new System.Drawing.Size(29, 17);
			this.toolStripStatusLabelCountDetail0.Text = "0/...";
			this.toolStripStatusLabelCountDetail0.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			//
			// toolStripDropDownButtonSaveDetail0
			//
			this.toolStripDropDownButtonSaveDetail0.Enabled = false;
			this.toolStripDropDownButtonSaveDetail0.Image = global::SIGEM.Client.Properties.Resources.apply;
			this.toolStripDropDownButtonSaveDetail0.ImageTransparentColor = System.Drawing.Color.Magenta;
			this.toolStripDropDownButtonSaveDetail0.Margin = new System.Windows.Forms.Padding(0, 3, 0, 2);
			this.toolStripDropDownButtonSaveDetail0.Name = "toolStripDropDownButtonSaveDetail0";
			this.toolStripDropDownButtonSaveDetail0.ShowDropDownArrow = false;
			this.toolStripDropDownButtonSaveDetail0.Size = new System.Drawing.Size(66, 17);
			this.toolStripDropDownButtonSaveDetail0.Text = "Save";
			this.toolStripDropDownButtonSaveDetail0.Visible = false;
            //
            // panelFormMDButtons
            //
            this.panelFormMDButtons.Controls.Add(this.bCancel);
            this.panelFormMDButtons.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelFormMDButtons.Location = new System.Drawing.Point(0, 500);
            this.panelFormMDButtons.Name = "panelFormMDButtons";
            this.panelFormMDButtons.Size = new System.Drawing.Size(550, 30);
            this.panelFormMDButtons.TabIndex = 2;
			//
			// bCancel
			//
			this.bCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.bCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.bCancel.Location = new System.Drawing.Point(472, 4);
			this.bCancel.Margin = new System.Windows.Forms.Padding(2);
			this.bCancel.Name = "bCancel";
			this.bCancel.Size = new System.Drawing.Size(75, 23);
			this.bCancel.TabIndex = 0;
			this.bCancel.Text = "Close";
			this.bCancel.UseVisualStyleBackColor = true;
			//
			// MDIU_PasajeroAeronaveIT
			//
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.bCancel;
			this.ClientSize = new System.Drawing.Size(550, 530);
			this.Controls.Add(this.splitMD);
            this.Controls.Add(this.panelFormMDButtons);
			this.Name = "MDIU_PasajeroAeronaveIT";
			this.Text = "PasajeroAeronave";
			this.splitMD.Panel1.ResumeLayout(false);
			this.splitMD.Panel2.ResumeLayout(false);
			this.splitMD.Panel1.PerformLayout();
			this.splitMD.Panel2.PerformLayout();
			this.splitMD.ResumeLayout(false);
            this.MastercontextMenuStrip.ResumeLayout(false);
            this.pnlOIDSelectorMaster.ResumeLayout(false);
            this.pnlOIDSelectorMaster.PerformLayout();
			this.pnlActionsMaster.ResumeLayout(false);
			this.toolstripActionsMaster.ResumeLayout(false);
			this.toolstripActionsMaster.PerformLayout();
			this.pnlNavigationsMaster.ResumeLayout(false);
			this.pnlNavigationsMaster.PerformLayout();
			this.toolstripNavigationsMaster.ResumeLayout(false);
			this.toolstripNavigationsMaster.PerformLayout();
			this.pnlDisplaySetMaster.ResumeLayout(false);
			this.pnlDisplaySetMaster.PerformLayout();
			this.Detail0contextMenuStrip.ResumeLayout(false);
			this.pnlActionsDetail0.ResumeLayout(false);
			this.pnlActionsDetail0.PerformLayout();
			this.toolstripActionsDetail0.ResumeLayout(false);
			this.toolstripActionsDetail0.PerformLayout();
			this.pnlNavigationsDetail0.ResumeLayout(false);
			this.pnlNavigationsDetail0.PerformLayout();
			this.toolstripNavigationsDetail0.ResumeLayout(false);
			this.toolstripNavigationsDetail0.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.gPopulationDetail0)).EndInit();
			this.statusStripDisplaySetInfoAuxDetail0.ResumeLayout(false);
			this.statusStripDisplaySetInfoAuxDetail0.PerformLayout();
            this.panelFormMDButtons.ResumeLayout(false);
			this.ResumeLayout(false);
		}

		#endregion

		private System.Windows.Forms.SplitContainer splitMD;
		private System.Windows.Forms.ContextMenuStrip  MastercontextMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem MastertoolStripHelp;
		private System.Windows.Forms.ToolStripMenuItem MasteroptionsToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator MastertoolStripSeparator1;
		private System.Windows.Forms.ToolStripSeparator MastertoolStripSeparator2;
		private System.Windows.Forms.ToolStripMenuItem MastertoolStripExportExcel;
		private System.Windows.Forms.ToolStripMenuItem MastertoolStripExportWord;
		private System.Windows.Forms.ToolStripSeparator MastertoolStripSeparatorOptions;
		private System.Windows.Forms.ToolStripMenuItem MastertoolStripRefresh;
		private System.Windows.Forms.ToolStripMenuItem MastertoolStripPreferences;
		private System.Windows.Forms.ToolStripMenuItem MastertoolStripSavePositions;
		private System.Windows.Forms.Panel pnlActionsMaster;
		private System.Windows.Forms.ToolStrip toolstripActionsMaster;
		private System.Windows.Forms.ToolStripMenuItem mnuActionsMaster_0;
		private System.Windows.Forms.ToolStripButton toolstripActionsMaster_0;
		private System.Windows.Forms.ToolStripMenuItem mnuActionsMaster_1;
		private System.Windows.Forms.ToolStripButton toolstripActionsMaster_1;
		private System.Windows.Forms.ToolStripMenuItem mnuActionsMaster_2;
		private System.Windows.Forms.ToolStripButton toolstripActionsMaster_2;
		private System.Windows.Forms.ToolStripMenuItem mnuActionsMaster_3;
		private System.Windows.Forms.ToolStripButton toolstripActionsMaster_3;
		private System.Windows.Forms.ToolStripMenuItem mnuActionsMaster_4;
		private System.Windows.Forms.ToolStripButton toolstripActionsMaster_4;
		private System.Windows.Forms.ToolStripMenuItem mnuPrintMaster;
		private System.Windows.Forms.ToolStripButton toolStripPrintMaster;
		private System.Windows.Forms.ToolStripMenuItem mnuNavigationsMaster;
		private System.Windows.Forms.Panel pnlNavigationsMaster;
		private System.Windows.Forms.ToolStrip toolstripNavigationsMaster;
		private System.Windows.Forms.ToolStripMenuItem mnuNavigationsMaster_0;
		private System.Windows.Forms.ToolStripButton toolstripNavigationsMaster_0;
		private System.Windows.Forms.ToolStripMenuItem mnuNavigationsMaster_1;
		private System.Windows.Forms.ToolStripButton toolstripNavigationsMaster_1;
		private System.Windows.Forms.ToolStripMenuItem mnuNavigationsMaster_2;
		private System.Windows.Forms.ToolStripButton toolstripNavigationsMaster_2;
		private System.Windows.Forms.Panel pnlOIDSelectorMaster;
		private System.Windows.Forms.Label lOIDSelectorMaster;
		private System.Windows.Forms.MaskedTextBox maskedTextBoxMasterid_PasajeroAeronave1;
		private System.Windows.Forms.Button bOIDSelectorMaster;
		private System.Windows.Forms.Label lSIOIDSelectorMaster;
		private System.Windows.Forms.Panel pnlDisplaySetMaster;
		private System.Windows.Forms.ListView lstViewDisplaySetMaster;
		private System.Windows.Forms.ColumnHeader lstViewDisplaySetMasterName;
		private System.Windows.Forms.ColumnHeader lstViewDisplaySetMasterValue;
		private System.Windows.Forms.ContextMenuStrip Detail0contextMenuStrip;
		private System.Windows.Forms.ToolStripMenuItem Detail0toolStripHelp;
		private System.Windows.Forms.ToolStripMenuItem Detail0optionsToolStripMenuItem;
		private System.Windows.Forms.ToolStripSeparator Detail0toolStripSeparator1;
		private System.Windows.Forms.ToolStripSeparator Detail0toolStripSeparator2;
		private System.Windows.Forms.ToolStripMenuItem Detail0toolStripExportExcel;
		private System.Windows.Forms.ToolStripMenuItem Detail0toolStripExportWord;
		private System.Windows.Forms.ToolStripSeparator Detail0toolStripSeparatorOptions;
		private System.Windows.Forms.ToolStripMenuItem Detail0toolStripRetrieveAll;
		private System.Windows.Forms.ToolStripMenuItem Detail0toolStripRefresh;
		private System.Windows.Forms.ToolStripMenuItem Detail0toolStripPreferences;
		private System.Windows.Forms.ToolStripMenuItem Detail0toolStripSaveColumnWidth;
		private System.Windows.Forms.Panel pnlActionsDetail0;
		private System.Windows.Forms.ToolStrip toolstripActionsDetail0;
		private System.Windows.Forms.ToolStripMenuItem mnuActionsDetail0_0;
		private System.Windows.Forms.ToolStripButton toolstripActionsDetail0_0;
		private System.Windows.Forms.ToolStripMenuItem mnuActionsDetail0_1;
		private System.Windows.Forms.ToolStripButton toolstripActionsDetail0_1;
		private System.Windows.Forms.ToolStripMenuItem mnuActionsDetail0_2;
		private System.Windows.Forms.ToolStripButton toolstripActionsDetail0_2;
		private System.Windows.Forms.ToolStripMenuItem mnuActionsDetail0_3;
		private System.Windows.Forms.ToolStripButton toolstripActionsDetail0_3;
		private System.Windows.Forms.ToolStripMenuItem mnuPrintDetail0;
		private System.Windows.Forms.ToolStripButton toolStripPrintDetail0;
		private System.Windows.Forms.ToolStripMenuItem mnuNavigationsDetail0;
		private System.Windows.Forms.Panel pnlNavigationsDetail0;
		private System.Windows.Forms.ToolStrip toolstripNavigationsDetail0;
		private System.Windows.Forms.ToolStripMenuItem mnuNavigationsDetail0_0;
		private System.Windows.Forms.ToolStripButton toolstripNavigationsDetail0_0;
		private System.Windows.Forms.DataGridView gPopulationDetail0;
		private System.Windows.Forms.StatusStrip statusStripDisplaySetInfoAuxDetail0;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelBlankDetail0;
		private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelCountDetail0;
		private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButtonSaveDetail0;
        private System.Windows.Forms.Panel panelFormMDButtons;
        private System.Windows.Forms.Button bCancel;
	}
}
