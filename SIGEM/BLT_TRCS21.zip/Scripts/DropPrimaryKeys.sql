ALTER TABLE NaveNodriza  DROP CONSTRAINT pk_NaveNodriza;

ALTER TABLE Aeronave  DROP CONSTRAINT pk_Aeronave;

ALTER TABLE Pasajero  DROP CONSTRAINT pk_Pasajero;

ALTER TABLE PasajeroAeronave  DROP CONSTRAINT pk_PasajeroAeronav;

ALTER TABLE Revision  DROP CONSTRAINT pk_Revision;

ALTER TABLE RevisionPasajero  DROP CONSTRAINT pk_RevisionPasajer;

ALTER TABLE Administrador  DROP CONSTRAINT pk_Administrador;
