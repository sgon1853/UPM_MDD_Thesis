DROP TABLE NaveNodriza;

DROP TABLE Aeronave;

DROP TABLE Pasajero;

DROP TABLE PasajeroAeronave;

DROP TABLE Revision;

DROP TABLE RevisionPasajero;

DROP TABLE Administrador;
