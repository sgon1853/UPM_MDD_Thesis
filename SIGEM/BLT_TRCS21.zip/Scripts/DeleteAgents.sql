DELETE Administrador WHERE ((id_Administrador = 1));
