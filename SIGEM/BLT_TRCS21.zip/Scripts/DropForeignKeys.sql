ALTER TABLE PasajeroAeronave DROP CONSTRAINT fkc_PasajeroAer_41;

ALTER TABLE PasajeroAeronave DROP CONSTRAINT fkc_PasajeroAer_42;

ALTER TABLE RevisionPasajero DROP CONSTRAINT fkc_RevisionPas_61;

ALTER TABLE RevisionPasajero DROP CONSTRAINT fkc_RevisionPas_62;
