DROP INDEX PasajeroAeronave.Idx_PasajeroAer_41;

DROP INDEX PasajeroAeronave.Idx_PasajeroAer_42;

DROP INDEX RevisionPasajero.Idx_RevisionPas_61;

DROP INDEX RevisionPasajero.Idx_RevisionPas_62;
