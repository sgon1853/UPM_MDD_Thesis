INSERT INTO Administrador(id_Administrador, PassWord, estadoobj, fum) VALUES(1, 'Q', 'Admini0', '25-9-2012 23:11:16')
