// 3.4.4.5

using System;
using System.Data.SqlClient;
using SIGEM.Business.XML;

namespace SIGEM.Business.Types
{
	/// <summary>
	/// IONType.
	/// </summary>
	public interface IONType
	{
		object Value{get;set;}
	}
}

