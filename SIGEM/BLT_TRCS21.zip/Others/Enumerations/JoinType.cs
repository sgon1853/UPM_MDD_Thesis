using System;

namespace SIGEM.Business.Others.Enumerations
{
	public enum JoinType
	{
		InnerJoin,
		LeftJoin
	}
}
