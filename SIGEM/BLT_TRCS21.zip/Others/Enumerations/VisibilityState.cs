// 3.4.4.5
using System;

namespace SIGEM.Business
{
	public enum VisibilityState
	{
		NotChecked,
		Visible,
		NotVisible
	}
}
