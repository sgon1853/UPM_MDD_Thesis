// 3.4.4.5

using System;

namespace SIGEM.Business
{
	public enum OrderByTypeEnumerator
	{
		Asc,
		Des
	}
}

