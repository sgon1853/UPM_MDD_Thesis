using System;

namespace SIGEM.Business
{
	public abstract class GlobalTransactionText
	{
		#region Services
		#endregion Services
	}
}
