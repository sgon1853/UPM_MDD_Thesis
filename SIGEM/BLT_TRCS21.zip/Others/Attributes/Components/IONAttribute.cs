// 3.4.4.5

using System;

namespace SIGEM.Business.Attributes
{
	/// <summary>
	/// Interface of the attributes used in the server.
	/// </summary>
	internal interface IONAttribute
	{
		string ToString();
	}
}

