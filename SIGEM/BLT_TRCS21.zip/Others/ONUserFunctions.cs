// 3.4.4.5
using System;
using SIGEM.Business.Types;
using SIGEM.Business.Exceptions;
using SIGEM.Business.OID;

namespace SIGEM.Business
{
	internal abstract class ONUserFunctions
	{
		#region User Functions
		#endregion

	}
}
